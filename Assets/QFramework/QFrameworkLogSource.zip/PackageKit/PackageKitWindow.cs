using UnityEditor;

namespace QF.PackageKit
{
    public class PackageKitWindow : EditorWindow
    {
        [MenuItem("QFramework/PackageKit %t")]
        static void Open()
        {
            
        }
    }
}